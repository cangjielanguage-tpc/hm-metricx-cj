/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
 */
import type { HapPlugin } from '@ohos/hvigor-ohos-plugin/src/plugin/hap-plugin';
import { BaseCangjiePlugin } from './base-cangjie-plugin';
/**
 * cangjie hap plugin
 *
 * @since 2024/1/6
 */
export declare class CangjieHapPlugin extends BaseCangjiePlugin {
    private hapPlugin;
    constructor(hapPlugin: HapPlugin);
    initCangjieTasks(): Promise<void>;
}
