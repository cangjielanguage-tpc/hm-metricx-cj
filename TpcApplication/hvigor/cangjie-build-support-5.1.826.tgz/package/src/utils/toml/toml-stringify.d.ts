import { type CommentRecord } from './toml-parse';
export declare function stringifyToml(obj: unknown, commentMap: Map<string, CommentRecord[]>): string;
