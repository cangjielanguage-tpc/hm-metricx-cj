/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
 */
import type CustomTomlDate from './custom-toml-date';
import type { ObjType } from './toml-enum';
export interface MetaState {
    objType: ObjType;
    undo: boolean;
    index: number;
    record: MetaRecord;
}
export interface MetaRecord {
    [k: string]: MetaState;
}
export declare type TableRecord = [string, Record<string, CustomTomlTypes>, MetaRecord] | null;
export declare type CustomTomlTypes = string | number | boolean | CustomTomlDate | {
    [key: string]: CustomTomlTypes;
} | CustomTomlTypes[];
