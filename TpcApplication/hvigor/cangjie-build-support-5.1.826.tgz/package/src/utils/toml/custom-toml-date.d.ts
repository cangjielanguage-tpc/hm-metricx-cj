export default class CustomTomlDate extends Date {
    protected includeDate: boolean;
    protected includeTime: boolean;
    protected dateOffset: string | null;
    constructor(date: string | Date, includeDate?: boolean, includeTime?: boolean, dateOffset?: string | null);
    static createCustomTomlDate(dateParam: string | Date): CustomTomlDate;
    isDate(): boolean;
    isTime(): boolean;
    isValid(): boolean;
    toISOString(): string;
}
