export declare class CangjieAdaptorError extends Error {
    static readonly NAME = "AdaptorError";
    constructor(message?: string);
}
