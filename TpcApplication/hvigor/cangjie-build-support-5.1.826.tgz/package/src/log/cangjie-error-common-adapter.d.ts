import { CangjieErrorDetail } from './cangjie-error-info';
/**
 * 打印报错的通用适配器
 */
export declare class CangjieErrorCommonAdapter {
    static red: string;
    /**
     * 组装完整三段式的错误信息
     * @private
     */
    combinePhase(errorInfo: CangjieErrorDetail): string;
    /**
     * 组装三段式的第一段：错误码+描述
     * @param errorInfo
     * @returns
     */
    private combinePhase1;
    /**
     * 组装三段式的第二段：错误原因+报错位置
     * @param errorInfo
     * @returns
     */
    private combinePhase2;
    /**
     * 对于printMergedError()的场景需要将错误原因和报错位置配对
     * 通过merge时的特殊分割点SPLIT_TAG来进行分割，有两种情况：
     * 1、cause数量和position数量一致：一一配对
     * 2、cause数量和position数量不一致：
     * 1）cause全量 + position一个： 需要将每个cause一行 + position单独放最后一行
     * 2）cause一个 + position全量： 需要将每个cause一行 + position每个单独放一行
     *
     * @param cause
     * @param position
     * @returns
     */
    private composeCauseAndPosition;
    /**
     * 原因和位置一一对应拼接
     * @param causeList
     * @param positionList
     * @param at
     * @param resParam
     * @returns
     */
    private composeCauseAndPositionWithSameLength;
    /**
     * 原因和位置纵向排列
     * @param causeList
     * @param positionList
     * @param at
     * @param resParam
     * @returns
     */
    private composeCauseAndPositionWithUnSameLength;
    /**
     * 组装三段式的第三段：解决方案
     * @param errorInfo
     * @returns
     */
    private combinePhase3;
}
