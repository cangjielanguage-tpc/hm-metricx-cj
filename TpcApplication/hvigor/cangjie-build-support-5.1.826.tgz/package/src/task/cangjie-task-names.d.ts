/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
 */
import type { TaskDetails } from '@ohos/hvigor';
/**
 * cangjie task names
 *
 * @since 2024/1/6
 */
export declare class CangjieTaskNames {
    static readonly COMPILE_CJ_NODE: TaskDetails;
    static readonly GENERATE_CJ_RESOURCE: TaskDetails;
    static readonly PROCESS_CJ_LIBS: TaskDetails;
    static readonly PREVIEW_GENERATE_CJ_RESOURCE: TaskDetails;
    static readonly AFTER_COMPILE_CANGJIE: TaskDetails;
    static readonly MOVE_CANGJIE_LIBS: TaskDetails;
    static readonly SYNC_CJ_RESOURCE: TaskDetails;
    static readonly CANGJIE_PRE_BUILD: TaskDetails;
    static readonly GENERATE_CANGJIE_INTEROP_API: TaskDetails;
    static readonly COMPILE_CANGJIE_FOR_IDL: TaskDetails;
    static readonly GENERATE_TOML_DEPENDENCIES: TaskDetails;
    static readonly BEFORE_PROCESS_LIBS: TaskDetails;
    static readonly ADD_API_DEPENDENCIES: TaskDetails;
    static readonly GENERATE_API_DEPENDENCIES: TaskDetails;
}
