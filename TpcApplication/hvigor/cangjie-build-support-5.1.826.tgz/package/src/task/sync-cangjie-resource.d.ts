import { AbstractModuleHookTask } from '@ohos/hvigor-ohos-plugin/src/tasks/hook/abstract-module-hook-task';
import type { ModuleTaskService } from '@ohos/hvigor-ohos-plugin/src/tasks/service/module-task-service';
import type { TargetTaskService } from '@ohos/hvigor-ohos-plugin/src/tasks/service/target-task-service';
/**
 * sync cangjie resource
 *
 * @since 2024/5/6
 */
export declare class SyncCangjieResource extends AbstractModuleHookTask {
    constructor(moduleTaskService: ModuleTaskService);
    initTaskDepends(taskTargetService: TargetTaskService): void;
}
