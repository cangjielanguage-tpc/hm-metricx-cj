/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
 */
import type { TargetTaskService } from '@ohos/hvigor-ohos-plugin/src/tasks/service/target-task-service';
import { AbstractProcessCangjieLibs } from './abstract-process-cangjie-libs';
/**
 * process cangjie libs task
 *
 * @since 2024/5/6
 */
export declare class ProcessCangjieLibs extends AbstractProcessCangjieLibs {
    private pclLogger;
    private readonly _moduleDir;
    constructor(taskService: TargetTaskService);
    initTaskDepends(): void;
    protected doTaskAction(): Promise<void>;
    private copyStdRuntimeLibs;
    private copyProcessCangjieLibsDirect;
}
