import { BaseCangjieTask } from '../base-cangjie-task';
import { TargetTaskService } from '@ohos/hvigor-ohos-plugin/src/tasks/service/target-task-service';
/**
 * generate api dependencies
 *
 * @since 2024/12/15
 */
export declare class AddApiDependencies extends BaseCangjieTask {
    private aadLogger;
    private tpcEnvMap;
    constructor(taskService: TargetTaskService);
    initTaskDepends(): void;
    protected doTaskAction(): void;
    private addApiDependencies;
    private readToml;
    private doAddApiDepends;
    private updateTomlContent;
}
