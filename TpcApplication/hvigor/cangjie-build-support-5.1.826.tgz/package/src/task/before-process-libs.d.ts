/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
 */
import type { TargetTaskService } from '@ohos/hvigor-ohos-plugin/src/tasks/service/target-task-service';
import { BaseCangjieTask } from './base-cangjie-task';
/**
 * before process libs
 *
 * @since 2024/1/6
 */
export declare class BeforeProcessLibs extends BaseCangjieTask {
    private cppDependLibs;
    constructor(taskService: TargetTaskService);
    initTaskDepends(): void;
    protected doTaskAction(): Promise<void>;
    protected doCopyCppLibs(folderPath: string, destPath: string, cppDependLibs: string[], abi: string): Promise<void>;
}
